function cadastrarUsuario() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const errorMessageElement = document.getElementById('error-message');

  if (!email || !password) {
    errorMessageElement.textContent = "Por favor, preencha todos os campos.";
    return;
  }

  firebase.auth().createUserWithEmailAndPassword(email, password)
    .then((userCredential) => {
      const user = userCredential.user;
      alert("Usuário cadastrado com sucesso! E-mail: " + user.email);
      document.getElementById('email').value = '';
      document.getElementById('password').value = '';
    })
    .catch((error) => {
      const errorCode = error.code;
      const errorMessage = error.message;

      if (errorCode === 'auth/email-already-in-use') {
        errorMessageElement.textContent = "Este e-mail já está em uso. Tente outro.";
      } else if (errorCode === 'auth/weak-password') {
        errorMessageElement.textContent = "A senha deve ter pelo menos 6 caracteres.";
      } else {
        errorMessageElement.textContent = "Erro ao cadastrar. Tente novamente.";
      }
    });
}
